"""
Package des cogs du bot Delamain
"""
